var loader = document.querySelector(".loader");

window.addEventListener("load", wipe);
window.addEventListener;
function wipe() {
  loader.classList.add("disappear");
}